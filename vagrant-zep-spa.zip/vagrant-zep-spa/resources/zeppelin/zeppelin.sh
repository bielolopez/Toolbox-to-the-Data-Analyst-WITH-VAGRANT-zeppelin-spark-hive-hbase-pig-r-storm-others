#!/bin/sh

export ZEPPELIN_PREFIX=/opt/zeppelin
export PATH=${ZEPPELIN_PREFIX}/bin:${PATH}
