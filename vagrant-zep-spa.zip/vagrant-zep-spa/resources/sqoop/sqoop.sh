#!/bin/sh

SQOOP_PREFIX=/usr/local/sqoop
export SQOOP_HOME=${SQOOP_PREFIX}
export PATH=${PATH}:${SQOOP_PREFIX}/bin
