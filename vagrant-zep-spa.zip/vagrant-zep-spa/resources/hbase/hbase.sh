#!/bin/sh
export HBASE_HOME=/usr/local/hbase
export HBASE_CONF_DIR=$HBASE_HOME/conf
export PATH=${HBASE_HOME}/bin:${PATH}
