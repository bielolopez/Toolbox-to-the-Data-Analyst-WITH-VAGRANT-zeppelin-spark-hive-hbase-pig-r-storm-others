#!/bin/sh

export SPARK_HOME=/usr/local/spark
export PATH=${SPARK_HOME}/bin:${SPARK_HOME}/sbin:${PATH}